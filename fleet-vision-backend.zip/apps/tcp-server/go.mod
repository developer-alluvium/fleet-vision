module fleet-vision/tcp-server

go 1.18

require github.com/segmentio/kafka-go v0.4.51

require (
	github.com/klauspost/compress v1.15.9 // indirect
	github.com/pierrec/lz4/v4 v4.1.15 // indirect
)
