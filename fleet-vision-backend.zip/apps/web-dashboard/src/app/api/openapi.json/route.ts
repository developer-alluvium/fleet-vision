import { NextResponse } from "next/server";

export async function GET() {
  const openApiSpec = {
    openapi: "3.0.0",
    info: {
      title: "Fleet Vision API Documentation",
      version: "1.0.0",
      description:
        "Comprehensive API reference and interactive testing console for the Fleet Vision Enterprise Telemetry & Fleet Management Platform.\n\n" +
        "### Authentication\n" +
        "The API supports authentication via:\n" +
        "1. **Bearer Token (JWT)**: Include header `Authorization: Bearer <your_jwt_token>`.\n" +
        "2. **Organization API Key**: Include header `x-api-key: <your_api_key>`.\n" +
        "3. **HttpOnly Cookie**: Automatically sent by modern browsers after logging in via `/api/v1/auth/login`.\n\n" +
        "### Multi-Tenancy & Authorization\n" +
        "Requests are strictly scoped by Organization ID. Most endpoints will automatically derive the `orgId` from the caller's authentication context if omitted.",
    },
    servers: [
      {
        url: "http://localhost:3000",
        description: "Local Development Server (Localhost)",
      },
      {
        url: "http://192.168.0.160:3000",
        description: "Local Network Server",
      },
    ],
    tags: [
      {
        name: "Authentication",
        description: "Endpoints for user session management, login, logout, and token refresh.",
      },
      {
        name: "Organizations",
        description: "Endpoints for managing organizations, initial admin accounts, and API key generation.",
      },
      {
        name: "Vehicles",
        description: "Endpoints for vehicle registration, fleet listings, and BLE sensor calibrations.",
      },
      {
        name: "Devices",
        description: "Endpoints for registering telemetry hardware (IMEI), hardware listing, and vehicle assignment.",
      },
      {
        name: "Real-Time & Telemetry",
        description: "Endpoints for live vehicle positioning, Server-Sent Events (SSE) streaming, and journey trails.",
      },
      {
        name: "Analytics & History",
        description: "Endpoints for fetching historical TimescaleDB telemetry logs, trip summaries, and distance metrics.",
      },
      {
        name: "Geofences",
        description: "Endpoints for managing geofence zones, testing coordinates, and querying alert history.",
      },
      {
        name: "Alerts",
        description: "Real-time alert streaming via Server-Sent Events. Supports multiple alert categories including geofence boundary crossings, speed violations, and more.",
      },
    ],
    paths: {
      // ─────────────────────────────────────────────────────────
      // AUTHENTICATION
      // ─────────────────────────────────────────────────────────
      "/api/v1/auth/login": {
        post: {
          tags: ["Authentication"],
          summary: "Organization User Login",
          description:
            "Authenticates a user using email and password. Upon successful authentication, issues secure `access_token` and `refresh_token` HttpOnly cookies and returns the authenticated user object.",
          requestBody: {
            required: true,
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/LoginRequest" },
              },
            },
          },
          responses: {
            "200": {
              description: "Successful login. HttpOnly cookies set.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/LoginResponse" },
                },
              },
            },
            "400": {
              description: "Bad Request - Missing email or password.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "401": {
              description: "Unauthorized - Invalid email or password.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "500": {
              description: "Internal server error.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
          },
        },
      },
      "/api/v1/auth/me": {
        get: {
          tags: ["Authentication"],
          summary: "Get Current Authenticated User",
          description:
            "Returns details of the currently logged-in user. If the access token cookie is expired, automatically attempts to issue new access tokens using the refresh token.",
          security: [{ cookieAuth: [] }, { bearerAuth: [] }],
          responses: {
            "200": {
              description: "User details retrieved successfully.",
              content: {
                "application/json": {
                  schema: {
                    type: "object",
                    properties: {
                      user: { $ref: "#/components/schemas/User" },
                    },
                  },
                },
              },
            },
            "401": {
              description: "Unauthorized - Invalid, expired, or missing session token.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "500": {
              description: "Internal server error.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
          },
        },
      },
      "/api/v1/auth/refresh": {
        post: {
          tags: ["Authentication"],
          summary: "Refresh Access Token",
          description:
            "Exchanges a valid HttpOnly refresh token cookie for a brand new access token and refresh token.",
          security: [{ cookieAuth: [] }],
          responses: {
            "200": {
              description: "Token refreshed successfully.",
              content: {
                "application/json": {
                  schema: {
                    type: "object",
                    properties: {
                      message: { type: "string", example: "Token refreshed" },
                    },
                  },
                },
              },
            },
            "401": {
              description: "Unauthorized - Invalid or missing refresh token.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "500": {
              description: "Internal server error.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
          },
        },
      },
      "/api/v1/auth/logout": {
        post: {
          tags: ["Authentication"],
          summary: "User Logout",
          description:
            "Logs out the user by revoking the refresh token in Redis/Database and clearing authentication HttpOnly cookies.",
          security: [{ cookieAuth: [] }, { bearerAuth: [] }],
          responses: {
            "200": {
              description: "Successfully logged out.",
              content: {
                "application/json": {
                  schema: {
                    type: "object",
                    properties: {
                      message: { type: "string", example: "Logged out successfully" },
                    },
                  },
                },
              },
            },
            "500": {
              description: "Internal server error.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
          },
        },
      },

      // ─────────────────────────────────────────────────────────
      // ORGANIZATIONS
      // ─────────────────────────────────────────────────────────
      "/api/v1/organizations": {
        post: {
          tags: ["Organizations"],
          summary: "Create Organization & Admin Account",
          description:
            "Creates a new Organization record and its initial Admin User account in an atomic database transaction.",
          requestBody: {
            required: true,
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/RegisterOrgRequest" },
              },
            },
          },
          responses: {
            "201": {
              description: "Organization and Admin User created successfully.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/RegisterOrgResponse" },
                },
              },
            },
            "400": {
              description: "Validation error - Invalid email, missing name, or password length < 6.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "409": {
              description: "Conflict - A user with this email already exists.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "500": {
              description: "Internal server error.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
          },
        },
        get: {
          tags: ["Organizations"],
          summary: "List All Organizations",
          description:
            "Retrieves a list of all registered organizations along with counts of associated users, devices, and vehicles.",
          responses: {
            "200": {
              description: "List of organizations retrieved.",
              content: {
                "application/json": {
                  schema: {
                    type: "object",
                    properties: {
                      organizations: {
                        type: "array",
                        items: { $ref: "#/components/schemas/Organization" },
                      },
                    },
                  },
                },
              },
            },
            "500": {
              description: "Internal server error.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
          },
        },
      },
      "/api/v1/organizations/api-key": {
        post: {
          tags: ["Organizations"],
          summary: "Generate Organization API Key",
          description:
            "Generates a new secure 64-character hex API key (`fv_live_...`) for the caller's organization. Requires a valid JWT user login session.",
          security: [{ bearerAuth: [] }, { cookieAuth: [] }],
          responses: {
            "201": {
              description: "New API Key generated successfully.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ApiKeyResponse" },
                },
              },
            },
            "401": {
              description: "Unauthorized - Missing JWT token.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "403": {
              description: "Forbidden - Must be logged in as a user (API key auth cannot generate API keys).",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "500": {
              description: "Internal server error.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
          },
        },
        get: {
          tags: ["Organizations"],
          summary: "Get Stored API Key",
          description:
            "Fetches the existing API key for the caller's organization. Requires a valid JWT user login session.",
          security: [{ bearerAuth: [] }, { cookieAuth: [] }],
          responses: {
            "200": {
              description: "API key retrieved.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ApiKeyResponse" },
                },
              },
            },
            "401": {
              description: "Unauthorized - Missing JWT token.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "403": {
              description: "Forbidden - Must be logged in as a user.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "500": {
              description: "Internal server error.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
          },
        },
      },
      "/api/v1/organizations/{id}": {
        get: {
          tags: ["Organizations"],
          summary: "Get Detailed Organization Information",
          description:
            "Retrieves detailed profile information for a specific organization by its unique ID, including operational metrics and aggregate counts for associated users, GPS tracker hardware (devices), fleet vehicles, and geofences.\n\n" +
            "### Access Control & Tenant Scoping\n" +
            "- **Multi-Tenant Isolation**: Callers are restricted to viewing their own organization (`auth.organizationId === params.id`). Any attempt to inspect foreign tenant data returns `403 Forbidden`.\n" +
            "- **Role-Based Attribute Redaction**: Sensitive administrative secrets such as `apiKey` and `stripeCustomerId` are automatically redacted unless the requesting user possesses the `ADMIN` role or authentication was performed using a valid Organization API Key.",
          security: [
            { bearerAuth: [] },
            { apiKeyAuth: [] },
            { apiKeyAuthQuery: [] },
            { cookieAuth: [] },
          ],
          parameters: [
            {
              name: "id",
              in: "path",
              required: true,
              description: "The unique identifier (`cuid`) of the organization.",
              schema: {
                type: "string",
                example: "cm0123456789",
              },
            },
          ],
          responses: {
            "200": {
              description: "Detailed organization information and resource counts retrieved successfully.",
              content: {
                "application/json": {
                  schema: {
                    $ref: "#/components/schemas/OrganizationDetailsResponse",
                  },
                },
              },
            },
            "401": {
              description: "Unauthorized - Missing or invalid authentication token / API key.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "403": {
              description: "Forbidden - Caller does not belong to the requested organization.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "404": {
              description: "Not Found - Organization with the specified ID does not exist.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "500": {
              description: "Internal server error.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
          },
        },
        patch: {
          tags: ["Organizations"],
          summary: "Update Organization Settings",
          description: "Update settings such as the global speed limit for the organization.",
          security: [
            { bearerAuth: [] },
            { apiKeyAuth: [] },
            { cookieAuth: [] },
          ],
          parameters: [
            {
              name: "id",
              in: "path",
              required: true,
              description: "The unique identifier (`cuid`) of the organization.",
              schema: {
                type: "string",
              },
            },
          ],
          requestBody: {
            required: true,
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    globalSpeedLimitKmh: { type: "number", example: 100 },
                  },
                },
              },
            },
          },
          responses: {
            "200": {
              description: "Organization settings updated successfully.",
              content: {
                "application/json": {
                  schema: {
                    type: "object",
                    properties: {
                      organization: { $ref: "#/components/schemas/Organization" },
                    },
                  },
                },
              },
            },
            "400": { description: "Invalid request payload." },
            "401": { description: "Unauthorized." },
            "403": { description: "Forbidden - Admin privileges required." },
          },
        },
      },

      // ─────────────────────────────────────────────────────────
      // VEHICLES
      // ─────────────────────────────────────────────────────────
      "/api/v1/vehicles": {
        post: {
          tags: ["Vehicles"],
          summary: "Register New Vehicle",
          description:
            "Registers a new fleet vehicle in the database. Verifies uniqueness of plate number and VIN.",
          security: [{ bearerAuth: [] }, { apiKeyAuth: [] }, { cookieAuth: [] }],
          requestBody: {
            required: true,
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/RegisterVehicleRequest" },
              },
            },
          },
          responses: {
            "201": {
              description: "Vehicle registered successfully.",
              content: {
                "application/json": {
                  schema: {
                    type: "object",
                    properties: {
                      vehicle: { $ref: "#/components/schemas/Vehicle" },
                    },
                  },
                },
              },
            },
            "400": {
              description: "Bad Request - Missing required parameters or invalid JSON payload.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "401": {
              description: "Unauthorized - Authentication required.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "403": {
              description: "Forbidden - Attempted to create vehicle in unauthorized organization.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "404": {
              description: "Not Found - Specified organization does not exist.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "409": {
              description: "Conflict - A vehicle with this plate number or VIN already exists.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "500": {
              description: "Internal server error.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
          },
        },
        get: {
          tags: ["Vehicles"],
          summary: "List Organization Vehicles",
          description:
            "Lists all registered vehicles for an organization, including currently assigned hardware devices.",
          security: [{ bearerAuth: [] }, { apiKeyAuth: [] }, { cookieAuth: [] }],
          parameters: [
            {
              name: "orgId",
              in: "query",
              required: false,
              schema: { type: "string" },
              description: "Optional Organization ID (derived automatically from auth token if omitted).",
            },
          ],
          responses: {
            "200": {
              description: "Vehicles retrieved successfully.",
              content: {
                "application/json": {
                  schema: {
                    type: "object",
                    properties: {
                      vehicles: {
                        type: "array",
                        items: { $ref: "#/components/schemas/Vehicle" },
                      },
                    },
                  },
                },
              },
            },
            "400": {
              description: "Missing orgId parameter when auth context has no organization.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "401": {
              description: "Unauthorized.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "403": {
              description: "Forbidden.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "500": {
              description: "Internal server error.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
          },
        },
      },
      "/api/v1/vehicles/{vehicleId}": {
        patch: {
          tags: ["Vehicles"],
          summary: "Update Vehicle Properties",
          description: "Updates properties for a specific vehicle, such as overriding the speed limit.",
          security: [{ bearerAuth: [] }, { apiKeyAuth: [] }, { cookieAuth: [] }],
          parameters: [
            {
              name: "vehicleId",
              in: "path",
              required: true,
              schema: { type: "string" },
            },
          ],
          requestBody: {
            required: true,
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    speedLimitKmh: { type: "number", nullable: true, example: 80 },
                  },
                },
              },
            },
          },
          responses: {
            "200": {
              description: "Vehicle updated successfully.",
              content: {
                "application/json": {
                  schema: {
                    type: "object",
                    properties: {
                      vehicle: { $ref: "#/components/schemas/Vehicle" },
                    },
                  },
                },
              },
            },
            "401": { description: "Unauthorized." },
            "403": { description: "Forbidden." },
            "404": { description: "Vehicle not found." },
          },
        },
      },
      "/api/v1/vehicles/{vehicleId}/fuel-calibration-table": {
        get: {
          tags: ["Vehicles"],
          summary: "Get Vehicle Fuel Calibration Table",
          description: "Retrieves the piecewise linear calibration table (Hz to Liters mapping) for a vehicle.",
          security: [{ bearerAuth: [] }, { apiKeyAuth: [] }, { cookieAuth: [] }],
          parameters: [
            {
              name: "vehicleId",
              in: "path",
              required: true,
              schema: { type: "string" },
              description: "Vehicle CUID",
            },
          ],
          responses: {
            "200": {
              description: "Fuel calibration table retrieved.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/FuelCalibrationTableResponse" },
                },
              },
            },
            "401": {
              description: "Unauthorized.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "403": {
              description: "Forbidden.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "404": {
              description: "Vehicle not found.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
          },
        },
        put: {
          tags: ["Vehicles"],
          summary: "Update Vehicle Fuel Calibration Table",
          description: "Replaces the entire fuel calibration table for a vehicle and invalidates the cache.",
          security: [{ bearerAuth: [] }, { apiKeyAuth: [] }, { cookieAuth: [] }],
          parameters: [
            {
              name: "vehicleId",
              in: "path",
              required: true,
              schema: { type: "string" },
              description: "Vehicle CUID",
            },
          ],
          requestBody: {
            required: true,
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/UpdateFuelCalibrationTableRequest" },
              },
            },
          },
          responses: {
            "200": {
              description: "Fuel calibration table updated successfully.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/FuelCalibrationTableResponse" },
                },
              },
            },
            "400": {
              description: "Bad Request - Invalid calibration points.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "401": {
              description: "Unauthorized.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
          },
        },
        delete: {
          tags: ["Vehicles"],
          summary: "Clear Vehicle Fuel Calibration Table",
          description: "Deletes all calibration points for a vehicle.",
          security: [{ bearerAuth: [] }, { apiKeyAuth: [] }, { cookieAuth: [] }],
          parameters: [
            {
              name: "vehicleId",
              in: "path",
              required: true,
              schema: { type: "string" },
              description: "Vehicle CUID",
            },
          ],
          responses: {
            "200": {
              description: "Fuel calibration table cleared.",
              content: {
                "application/json": {
                  schema: {
                    type: "object",
                    properties: {
                      success: { type: "boolean", example: true },
                    },
                  },
                },
              },
            },
          },
        },
      },

      // ─────────────────────────────────────────────────────────
      // DEVICES
      // ─────────────────────────────────────────────────────────
      "/api/v1/devices": {
        post: {
          tags: ["Devices"],
          summary: "Register Telemetry Device",
          description:
            "Registers a new hardware GPS device by 15-digit IMEI and synchronizes device credentials to Redis cache for low-latency TCP socket authentication.",
          security: [{ bearerAuth: [] }, { apiKeyAuth: [] }, { cookieAuth: [] }],
          requestBody: {
            required: true,
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/RegisterDeviceRequest" },
              },
            },
          },
          responses: {
            "201": {
              description: "Device registered and cached successfully.",
              content: {
                "application/json": {
                  schema: {
                    type: "object",
                    properties: {
                      device: { $ref: "#/components/schemas/Device" },
                    },
                  },
                },
              },
            },
            "400": {
              description: "Invalid IMEI or missing required fields.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "401": {
              description: "Unauthorized.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "403": {
              description: "Forbidden.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "404": {
              description: "Organization not found.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "409": {
              description: "Device IMEI already registered.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "500": {
              description: "Internal server error.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
          },
        },
        get: {
          tags: ["Devices"],
          summary: "List Registered Devices",
          description:
            "Retrieves all GPS tracking devices registered under an organization.",
          security: [{ bearerAuth: [] }, { apiKeyAuth: [] }, { cookieAuth: [] }],
          parameters: [
            {
              name: "orgId",
              in: "query",
              required: false,
              schema: { type: "string" },
              description: "Optional Organization ID (derived automatically from auth token if omitted).",
            },
          ],
          responses: {
            "200": {
              description: "Devices list retrieved successfully.",
              content: {
                "application/json": {
                  schema: {
                    type: "object",
                    properties: {
                      devices: {
                        type: "array",
                        items: { $ref: "#/components/schemas/Device" },
                      },
                    },
                  },
                },
              },
            },
            "400": {
              description: "Missing orgId parameter when auth context is absent.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "401": {
              description: "Unauthorized.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "500": {
              description: "Internal server error.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
          },
        },
      },
      "/api/v1/devices/{deviceId}/assign": {
        post: {
          tags: ["Devices"],
          summary: "Assign/Unassign Vehicle to Device",
          description:
            "Links a registered vehicle to a hardware telemetry device, or unlinks it when `vehicleId` is `null`.",
          security: [{ bearerAuth: [] }, { apiKeyAuth: [] }, { cookieAuth: [] }],
          parameters: [
            {
              name: "deviceId",
              in: "path",
              required: true,
              schema: { type: "string" },
              description: "Device CUID",
            },
          ],
          requestBody: {
            required: true,
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/AssignDeviceRequest" },
              },
            },
          },
          responses: {
            "200": {
              description: "Device updated successfully.",
              content: {
                "application/json": {
                  schema: {
                    type: "object",
                    properties: {
                      device: { $ref: "#/components/schemas/Device" },
                    },
                  },
                },
              },
            },
            "400": {
              description: "Bad Request - Vehicle belongs to a different organization.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "401": {
              description: "Unauthorized.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "403": {
              description: "Forbidden.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "404": {
              description: "Device or Vehicle not found.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "409": {
              description: "Vehicle is already assigned to another device.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "500": {
              description: "Internal server error.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
          },
        },
      },

      // ─────────────────────────────────────────────────────────
      // REAL-TIME & TELEMETRY
      // ─────────────────────────────────────────────────────────
      "/api/v1/track-vehicle": {
        post: {
          tags: ["Real-Time & Telemetry"],
          summary: "Batch Track Current Locations",
          security: [{ bearerAuth: [] }, { apiKeyAuth: [] }, { apiKeyAuthQuery: [] }, { cookieAuth: [] }],
          description: "Retrieves real-time GPS locations and telemetry data for a provided list of vehicle IMEIs. This endpoint is optimized for batch tracking, allowing you to pass up to 50 IMEIs in a single request to monitor fleet movements continuously.",
          requestBody: {
            required: true,
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/TrackVehicleRequest" },
              },
            },
          },
          responses: {
            "200": {
              description: "Array of tracking results.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/TrackVehicleResponse" },
                },
              },
            },
            "400": {
              description: "Bad Request. Invalid IMEI format or array limit exceeded.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "401": {
              description: "Unauthorized. Missing or invalid authentication.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "403": {
              description: "Forbidden. One or more IMEIs do not belong to the organization.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "500": {
              description: "Internal server error.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
          },
        },
      },

      "/api/v1/live-locations": {
        get: {
          tags: ["Real-Time & Telemetry"],
          summary: "Get Current Live Fleet Locations",
          description:
            "Queries Redis memory cache to return latest GPS positioning coordinates, ignition status, speed, and fuel levels for all devices in an organization.",
          security: [{ bearerAuth: [] }, { apiKeyAuth: [] }, { cookieAuth: [] }],
          parameters: [
            {
              name: "orgId",
              in: "query",
              required: false,
              schema: { type: "string" },
              description: "Optional Organization ID (derived from authentication context if omitted).",
            },
          ],
          responses: {
            "200": {
              description: "Live locations returned successfully.",
              content: {
                "application/json": {
                  schema: {
                    type: "object",
                    properties: {
                      locations: {
                        type: "array",
                        items: { $ref: "#/components/schemas/LiveLocation" },
                      },
                    },
                  },
                },
              },
            },
            "400": {
              description: "Missing orgId parameter when auth context is absent.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "401": {
              description: "Unauthorized.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "500": {
              description: "Internal server error.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
          },
        },
      },
      "/api/v1/stream/devices": {
        get: {
          tags: ["Real-Time & Telemetry"],
          summary: "Stream Filtered Realtime Devices (SSE)",
          description: "Long-lived Server-Sent Events (SSE) stream delivering realtime data for all devices of the authenticated organization. Supports server-side status filtering.",
          security: [{ bearerAuth: [] }, { apiKeyAuth: [] }, { cookieAuth: [] }],
          parameters: [
            {
              name: "status",
              in: "query",
              required: false,
              schema: { type: "string", default: "all" },
              description: "Comma-separated, case-insensitive filter. Allowed: all, running, idle, stopped, inactive, no_data.",
            },
            {
              name: "includeVehicle",
              in: "query",
              required: false,
              schema: { type: "boolean", default: true },
              description: "When false, the vehicle key is omitted from payloads.",
            },
            {
              name: "fields",
              in: "query",
              required: false,
              schema: { type: "string" },
              description: "Optional comma-separated whitelist of top-level payload keys.",
            },
            {
              name: "token",
              in: "query",
              required: false,
              schema: { type: "string" },
              description: "Bearer <jwt> for EventSource clients that cannot set headers.",
            }
          ],
          responses: {
            "200": {
              description: "SSE Stream started successfully. Begins with an `init` event.",
              content: {
                "text/event-stream": {
                  schema: { $ref: "#/components/schemas/StreamInitResponse" }
                }
              }
            },
            "400": {
              description: "Invalid status filter",
              content: { "application/json": { schema: { $ref: "#/components/schemas/ErrorResponse" } } }
            },
            "401": {
              description: "Authentication required",
              content: { "application/json": { schema: { $ref: "#/components/schemas/ErrorResponse" } } }
            },
            "429": {
              description: "Too many concurrent streams for this organization",
              content: { "application/json": { schema: { $ref: "#/components/schemas/ErrorResponse" } } }
            }
          }
        }
      },
      "/api/v1/stream/fleet": {
        get: {
          tags: ["Real-Time & Telemetry"],
          summary: "Stream Live Fleet Locations (SSE)",
          description:
            "Establishes a persistent Server-Sent Events (SSE) connection that streams real-time vehicle location updates across the organization.\n\n" +
            "**Events emitted:**\n" +
            "- `init`: Initial payload containing all devices and latest positions upon connection.\n" +
            "- `location:update`: Pushed instantly when a vehicle submits new telemetry.",
          security: [{ bearerAuth: [] }, { apiKeyAuth: [] }, { cookieAuth: [] }],
          responses: {
            "200": {
              description: "SSE connection established (Content-Type: text/event-stream).",
            },
            "401": {
              description: "Unauthorized.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "403": {
              description: "Forbidden.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "500": {
              description: "Internal server error.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
          },
        },
      },
      "/api/v1/stream/fleet-status": {
        get: {
          tags: ["Real-Time & Telemetry"],
          summary: "Stream Real-Time Fleet Status Summary (SSE)",
          description:
            "Establishes a persistent Server-Sent Events (SSE) connection that streams real-time fleet status counts (Running, Idle, Stopped, Inactive, No Data) across the organization.\n\n" +
            "**Events emitted:**\n" +
            "- `init`: Initial payload containing the latest status counts and computed timestamp upon connection.\n" +
            "- `update`: Pushed instantly when a vehicle transitions between states or counts change.",
          security: [{ bearerAuth: [] }, { apiKeyAuth: [] }, { cookieAuth: [] }],
          responses: {
            "200": {
              description: "SSE connection established (Content-Type: text/event-stream).",
            },
            "401": {
              description: "Unauthorized.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "403": {
              description: "Forbidden.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "500": {
              description: "Internal server error.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
          },
        },
      },
      "/api/v1/journey": {
        get: {
          tags: ["Real-Time & Telemetry"],
          summary: "Get Journey Path Coordinates",
          description:
            "Fetches ordered GPS path coordinates for a specific device IMEI.",
          security: [{ bearerAuth: [] }, { apiKeyAuth: [] }, { cookieAuth: [] }],
          parameters: [
            {
              name: "imei",
              in: "query",
              required: true,
              schema: { type: "string" },
              description: "15-digit Device IMEI number",
            },
            {
              name: "orgId",
              in: "query",
              required: false,
              schema: { type: "string" },
              description: "Optional Organization ID (derived automatically if omitted).",
            },
            {
              name: "since",
              in: "query",
              required: false,
              schema: { type: "string", format: "date-time" },
              description: "ISO 8601 start timestamp filter. Defaults to 1 hour ago.",
            },
          ],
          responses: {
            "200": {
              description: "Journey trail retrieved.",
              content: {
                "application/json": {
                  schema: {
                    type: "object",
                    properties: {
                      imei: { type: "string", example: "353456789012345" },
                      points: {
                        type: "array",
                        items: { $ref: "#/components/schemas/TelemetryPoint" },
                      },
                    },
                  },
                },
              },
            },
            "400": {
              description: "Invalid or missing imei parameter.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "401": {
              description: "Unauthorized.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "500": {
              description: "Internal server error.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
          },
        },
      },
      "/api/v1/stream/journey": {
        get: {
          tags: ["Real-Time & Telemetry"],
          summary: "Stream Live Single-Vehicle Journey (SSE)",
          description:
            "Establishes a zero-gap Server-Sent Events (SSE) stream for tracking a single vehicle's journey in real time.\n\n" +
            "**Events emitted:**\n" +
            "- `journey:history`: Emitted upon connection if `since` parameter is provided.\n" +
            "- `journey:point`: Continuous live stream of every incoming telemetry record.",
          security: [{ bearerAuth: [] }, { apiKeyAuth: [] }, { cookieAuth: [] }],
          parameters: [
            {
              name: "imei",
              in: "query",
              required: true,
              schema: { type: "string" },
              description: "15-digit Device IMEI number",
            },
            {
              name: "orgId",
              in: "query",
              required: false,
              schema: { type: "string" },
              description: "Optional Organization ID",
            },
            {
              name: "since",
              in: "query",
              required: false,
              schema: { type: "string", format: "date-time" },
              description: "ISO 8601 start timestamp for historical replay before live stream.",
            },
          ],
          responses: {
            "200": {
              description: "SSE connection established (Content-Type: text/event-stream).",
            },
            "400": {
              description: "Missing mandatory imei parameter.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "401": {
              description: "Unauthorized.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "404": {
              description: "Device not found in caller's organization.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "500": {
              description: "Internal server error.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
          },
        },
      },

      // ─────────────────────────────────────────────────────────
      // ANALYTICS & HISTORY
      // ─────────────────────────────────────────────────────────
      "/api/v1/reports/utilization": {
        get: {
          tags: ["Analytics & History"],
          summary: "Get Advanced Utilization Report",
          description:
            "Queries TimescaleDB telemetry data over a date range and computes per-vehicle driving, idle, and stopped durations, distance, speed, fuel, and utilization percentages.",
          security: [{ bearerAuth: [] }, { apiKeyAuth: [] }, { cookieAuth: [] }],
          parameters: [
            {
              name: "start",
              in: "query",
              required: false,
              schema: { type: "string", format: "date-time" },
              description: "Start timestamp filter (ISO 8601). Defaults to 24 hours ago.",
            },
            {
              name: "end",
              in: "query",
              required: false,
              schema: { type: "string", format: "date-time" },
              description: "End timestamp filter (ISO 8601). Defaults to current time.",
            },
            {
              name: "vehicleIds",
              in: "query",
              required: false,
              schema: { type: "string" },
              description: "Comma-separated list of vehicle IDs to filter by.",
            },
            {
              name: "groupBy",
              in: "query",
              required: false,
              schema: { type: "string", enum: ["hour", "day", "week"], default: "day" },
              description: "Time bucketing granularity for time series data.",
            },
          ],
          responses: {
            "200": {
              description: "Utilization report retrieved successfully.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/UtilizationReportResponse" },
                },
              },
            },
            "400": {
              description: "Invalid parameters or date range exceeds 90 days.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "401": {
              description: "Unauthorized.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "500": {
              description: "Internal server error.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
          },
        },
      },
      "/api/v1/reports/fuel-analytics": {
        get: {
          tags: ["Analytics & History"],
          summary: "Get Fleet Fuel Analytics Report",
          description:
            "Queries TimescaleDB telemetry data over a date range and computes comprehensive fleet-wide and per-vehicle fuel metrics including consumption, efficiency (km/L), refuel/drain event detection, and fuel level time-series.",
          security: [{ bearerAuth: [] }, { apiKeyAuth: [] }, { cookieAuth: [] }],
          parameters: [
            {
              name: "start",
              in: "query",
              required: false,
              schema: { type: "string", format: "date-time" },
              description: "Start timestamp filter (ISO 8601). Defaults to 24 hours ago.",
            },
            {
              name: "end",
              in: "query",
              required: false,
              schema: { type: "string", format: "date-time" },
              description: "End timestamp filter (ISO 8601). Defaults to current time.",
            },
            {
              name: "vehicleIds",
              in: "query",
              required: false,
              schema: { type: "string" },
              description: "Comma-separated list of vehicle IDs to filter by.",
            },
            {
              name: "groupBy",
              in: "query",
              required: false,
              schema: { type: "string", enum: ["hour", "day", "week"], default: "day" },
              description: "Time bucketing granularity for time series data.",
            },
          ],
          responses: {
            "200": {
              description: "Fuel analytics report retrieved successfully.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/FuelAnalyticsResponse" },
                },
              },
            },
            "400": {
              description: "Invalid parameters or date range exceeds 90 days.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "401": {
              description: "Unauthorized.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "500": {
              description: "Internal server error.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
          },
        },
      },
      "/api/v1/history": {
        get: {
          tags: ["Analytics & History"],
          summary: "Get Telemetry History & Trip Analytics",
          description:
            "Queries TimescaleDB hypertable logs for historical telemetry and aggregated metrics (total distance in km, driving vs. idle duration, max/avg speed, fuel consumption, and odometer readings).",
          security: [{ bearerAuth: [] }, { apiKeyAuth: [] }, { cookieAuth: [] }],
          parameters: [
            {
              name: "imei",
              in: "query",
              required: true,
              schema: { type: "string" },
              description: "15-digit Device IMEI number",
            },
            {
              name: "orgId",
              in: "query",
              required: false,
              schema: { type: "string" },
              description: "Optional Organization ID (derived automatically if omitted).",
            },
            {
              name: "start",
              in: "query",
              required: false,
              schema: { type: "string", format: "date-time" },
              description: "Start timestamp filter (ISO 8601). Defaults to 24 hours ago.",
            },
            {
              name: "end",
              in: "query",
              required: false,
              schema: { type: "string", format: "date-time" },
              description: "End timestamp filter (ISO 8601). Defaults to current time.",
            },
          ],
          responses: {
            "200": {
              description: "Telemetry history and trip summary retrieved successfully.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/HistoryResponse" },
                },
              },
            },
            "400": {
              description: "Missing imei or invalid date range format.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "401": {
              description: "Unauthorized.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "403": {
              description: "Forbidden - Access denied for requested device.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
            "500": {
              description: "Internal server error.",
              content: {
                "application/json": {
                  schema: { $ref: "#/components/schemas/ErrorResponse" },
                },
              },
            },
          },
        },
      },
      // ─────────────────────────────────────────────────────────
      // GEOFENCES
      // ─────────────────────────────────────────────────────────
      "/api/v1/geofences": {
        get: {
          tags: ["Geofences"],
          summary: "List Organization Geofences",
          description: "Fetches a paginated list of geofences for the current organization.",
          security: [{ bearerAuth: [] }, { apiKeyAuth: [] }, { cookieAuth: [] }],
          parameters: [
            { name: "page", in: "query", schema: { type: "integer", default: 1 } },
            { name: "limit", in: "query", schema: { type: "integer", default: 20 } },
            { name: "search", in: "query", schema: { type: "string" } },
            { name: "isActive", in: "query", schema: { type: "boolean" } }
          ],
          responses: {
            "200": {
              description: "List of geofences.",
              content: { "application/json": { schema: { $ref: "#/components/schemas/GeofenceListResponse" } } }
            }
          }
        },
        post: {
          tags: ["Geofences"],
          summary: "Create Geofence",
          description: "Creates a new geofence (POLYGON or CIRCLE) and enables live alert monitoring.",
          security: [{ bearerAuth: [] }, { apiKeyAuth: [] }, { cookieAuth: [] }],
          requestBody: {
            required: true,
            content: { "application/json": { schema: { $ref: "#/components/schemas/CreateGeofenceRequest" } } }
          },
          responses: {
            "201": {
              description: "Geofence created.",
              content: { "application/json": { schema: { type: "object", properties: { geofence: { $ref: "#/components/schemas/Geofence" } } } } }
            }
          }
        }
      },
      "/api/v1/geofences/{id}": {
        get: {
          tags: ["Geofences"],
          summary: "Get Geofence Details",
          security: [{ bearerAuth: [] }, { apiKeyAuth: [] }, { cookieAuth: [] }],
          parameters: [{ name: "id", in: "path", required: true, schema: { type: "string" } }],
          responses: {
            "200": {
              description: "Geofence details.",
              content: { "application/json": { schema: { type: "object", properties: { geofence: { $ref: "#/components/schemas/Geofence" } } } } }
            }
          }
        },
        put: {
          tags: ["Geofences"],
          summary: "Update Geofence",
          security: [{ bearerAuth: [] }, { apiKeyAuth: [] }, { cookieAuth: [] }],
          parameters: [{ name: "id", in: "path", required: true, schema: { type: "string" } }],
          requestBody: {
            required: true,
            content: { "application/json": { schema: { $ref: "#/components/schemas/UpdateGeofenceRequest" } } }
          },
          responses: {
            "200": {
              description: "Geofence updated.",
              content: { "application/json": { schema: { type: "object", properties: { success: { type: "boolean" } } } } }
            }
          }
        },
        delete: {
          tags: ["Geofences"],
          summary: "Delete Geofence",
          security: [{ bearerAuth: [] }, { apiKeyAuth: [] }, { cookieAuth: [] }],
          parameters: [{ name: "id", in: "path", required: true, schema: { type: "string" } }],
          responses: {
            "200": {
              description: "Geofence deleted.",
              content: { "application/json": { schema: { type: "object", properties: { success: { type: "boolean" } } } } }
            }
          }
        }
      },
      "/api/v1/geofences/{id}/test": {
        post: {
          tags: ["Geofences"],
          summary: "Test Point Against Geofence",
          description: "Tests whether a specific coordinate falls inside a geofence and returns the exact distance.",
          security: [{ bearerAuth: [] }, { apiKeyAuth: [] }, { cookieAuth: [] }],
          parameters: [{ name: "id", in: "path", required: true, schema: { type: "string" } }],
          requestBody: {
            required: true,
            content: { "application/json": { schema: { type: "object", properties: { latitude: { type: "number" }, longitude: { type: "number" } }, required: ["latitude", "longitude"] } } }
          },
          responses: {
            "200": {
              description: "Test result.",
              content: { "application/json": { schema: { type: "object", properties: { inside: { type: "boolean" }, distanceMeters: { type: "number" } } } } }
            }
          }
        }
      },
      "/api/v1/alerts/stream": {
        get: {
          tags: ["Alerts"],
          summary: "Real-Time Alert Stream (SSE)",
          description:
            "Server-Sent Events endpoint streaming live alerts for the entire organization. " +
            "Currently supports **geofence alerts** (`geofence:enter`, `geofence:exit`, `geofence:speed`). " +
            "Additional alert categories (maintenance, SOS, tampering, etc.) will be added to this same stream in the future.\n\n" +
            "### SSE Event Format\n" +
            "Each event includes a `category` field to distinguish alert types:\n" +
            "```\nevent: geofence:enter\ndata: {\"category\":\"geofence\", \"imei\":\"...\", \"geofenceId\":\"...\", ...}\n```\n\n" +
            "### Event Types\n" +
            "| Event Name | Category | Description |\n" +
            "|---|---|---|\n" +
            "| `geofence:enter` | geofence | Vehicle entered a geofence zone |\n" +
            "| `geofence:exit` | geofence | Vehicle exited a geofence zone |\n" +
            "| `geofence:speed` | geofence | Speed limit violated inside a geofence |\n",
          security: [{ bearerAuth: [] }, { cookieAuth: [] }],
          responses: {
            "200": {
              description: "Server-Sent Events stream of alert objects.",
              content: { "text/event-stream": { schema: { type: "string", description: "SSE stream with events prefixed by category (e.g. geofence:enter, geofence:exit, geofence:speed)" } } }
            },
            "401": {
              description: "Unauthorized - Invalid or missing authentication.",
              content: { "application/json": { schema: { $ref: "#/components/schemas/ErrorResponse" } } }
            }
          }
        }
      },
      "/api/v1/geofences/alerts": {
        get: {
          tags: ["Geofences"],
          summary: "List Geofence Alert History",
          description: "Fetches a paginated history of geofence crossing alerts.",
          security: [{ bearerAuth: [] }, { apiKeyAuth: [] }, { cookieAuth: [] }],
          parameters: [
            { name: "page", in: "query", schema: { type: "integer", default: 1 } },
            { name: "limit", in: "query", schema: { type: "integer", default: 50 } },
            { name: "geofenceId", in: "query", schema: { type: "string" } },
            { name: "imei", in: "query", schema: { type: "string" } },
            { name: "eventType", in: "query", schema: { type: "string", enum: ["ENTER", "EXIT", "SPEED_VIOLATION"] } },
            { name: "from", in: "query", schema: { type: "string", format: "date-time" } },
            { name: "to", in: "query", schema: { type: "string", format: "date-time" } }
          ],
          responses: {
            "200": {
              description: "List of alerts.",
              content: { "application/json": { schema: { $ref: "#/components/schemas/GeofenceAlertListResponse" } } }
            }
          }
        }
      },
      "/api/v1/alerts": {
        get: {
          tags: ["Alerts"],
          summary: "Get Historical Alerts",
          description: "Fetches historical alerts for the organization.",
          security: [{ bearerAuth: [] }, { apiKeyAuth: [] }, { cookieAuth: [] }],
          parameters: [
            {
              name: "page",
              in: "query",
              required: false,
              schema: { type: "integer", default: 1 },
            },
            {
              name: "limit",
              in: "query",
              required: false,
              schema: { type: "integer", default: 20 },
            },
            {
              name: "category",
              in: "query",
              required: false,
              schema: { type: "string" },
              description: "Filter by category (e.g., 'SPEED', 'GEOFENCE')",
            },
            {
              name: "eventType",
              in: "query",
              required: false,
              schema: { type: "string" },
              description: "Filter by eventType (e.g., 'ENTER', 'EXIT')",
            },
            {
              name: "geofenceId",
              in: "query",
              required: false,
              schema: { type: "string" },
              description: "Filter by geofence ID",
            },
            {
              name: "imei",
              in: "query",
              required: false,
              schema: { type: "string" },
              description: "Filter by specific device IMEI",
            },
            {
              name: "vehicleId",
              in: "query",
              required: false,
              schema: { type: "string" },
              description: "Filter by specific vehicle ID",
            },
            {
              name: "from",
              in: "query",
              required: false,
              schema: { type: "string", format: "date-time" },
              description: "Start date for timestamp filtering",
            },
            {
              name: "to",
              in: "query",
              required: false,
              schema: { type: "string", format: "date-time" },
              description: "End date for timestamp filtering",
            },
          ],
          responses: {
            "200": {
              description: "Historical alerts retrieved successfully.",
              content: {
                "application/json": {
                  schema: {
                    type: "object",
                    properties: {
                      alerts: {
                        type: "array",
                        items: {
                          type: "object",
                          properties: {
                            id: { type: "string" },
                            category: { type: "string" },
                            eventType: { type: "string" },
                            imei: { type: "string" },
                            speed: { type: "number", nullable: true },
                            metadata: { type: "object" },
                            timestamp: { type: "string", format: "date-time" },
                            device: {
                              type: "object",
                              nullable: true,
                              properties: {
                                id: { type: "string" },
                                imei: { type: "string" },
                                vehicle: {
                                  type: "object",
                                  nullable: true,
                                  properties: {
                                    id: { type: "string" },
                                    plateNumber: { type: "string" },
                                    make: { type: "string", nullable: true },
                                    model: { type: "string", nullable: true },
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                      totalCount: { type: "integer" },
                      totalPages: { type: "integer" },
                      page: { type: "integer" },
                      limit: { type: "integer" },
                    },
                  },
                },
              },
            },
            "401": { description: "Unauthorized." },
            "500": { description: "Internal server error." },
          },
        },
      }
    },
    components: {
      securitySchemes: {
        bearerAuth: {
          type: "http",
          scheme: "bearer",
          bearerFormat: "JWT",
          description: "Enter your JWT Bearer token (e.g. `eyJhbGciOi...`).",
        },
        apiKeyAuth: {
          type: "apiKey",
          in: "header",
          name: "x-api-key",
          description: "Enter your Organization API key (e.g. `fv_live_...`).",
        },
        apiKeyAuthQuery: {
          type: "apiKey",
          in: "query",
          name: "apiKey",
          description: "Enter your Organization API key as a query parameter (e.g. `?apiKey=fv_live_...`).",
        },
        cookieAuth: {
          type: "apiKey",
          in: "cookie",
          name: "access_token",
          description: "HttpOnly session cookie automatically set upon login.",
        },
      },
      schemas: {
        DeviceRealtimePayload: {
          type: "object",
          properties: {
            imei: { type: "string" },
            deviceId: { type: "string" },
            deviceStatus: { type: "string" },
            status: { type: "string" },
            previousStatus: { type: "string" },
            latitude: { type: "number", nullable: true },
            longitude: { type: "number", nullable: true },
            speed: { type: "number", nullable: true },
            angle: { type: "number", nullable: true },
            ignition: { type: "boolean", nullable: true },
            fuelLevelRaw: { type: "number", nullable: true },
            fuelLevelLiters: { type: "number", nullable: true },
            odometer: { type: "number", nullable: true },
            timestamp: { type: "string", format: "date-time", nullable: true },
            updatedAt: { type: "string", format: "date-time", nullable: true },
            lastSeenAgeSec: { type: "number", nullable: true },
            vehicle: { type: "object", nullable: true }
          }
        },
        StreamInitResponse: {
          type: "object",
          properties: {
            organizationId: { type: "string" },
            serverTime: { type: "string", format: "date-time" },
            filter: { type: "object" },
            thresholds: { type: "object" },
            summary: { type: "object" },
            devices: {
              type: "array",
              items: { $ref: "#/components/schemas/DeviceRealtimePayload" }
            }
          }
        },
        TrackVehicleRequest: {
          type: "object",
          required: ["imeis"],
          properties: {
            imeis: {
              type: "array",
              description: "Array of 15-digit Device IMEIs (Max 50)",
              items: {
                type: "string",
                example: "353456789012345",
              },
            },
          },
        },
        TrackVehicleResponse: {
          type: "object",
          required: ["results"],
          properties: {
            results: {
              type: "array",
              items: {
                type: "object",
                required: ["imei", "found"],
                properties: {
                  imei: { type: "string" },
                  found: { type: "boolean" },
                  location: {
                    type: "object",
                    nullable: true,
                    properties: {
                      latitude: { type: "number" },
                      longitude: { type: "number" },
                      speed: { type: "number" },
                      angle: { type: "number" },
                      ignition: { type: "boolean" },
                      fuelLevelRaw: { type: "number", nullable: true },
                      odometer: { type: "number", nullable: true },
                      timestamp: { type: "string", format: "date-time" },
                      updatedAt: { type: "string", format: "date-time" },
                    },
                  },
                },
              },
            },
          },
        },
        ErrorResponse: {
          type: "object",
          required: ["error"],
          properties: {
            error: {
              type: "string",
              example: "Unauthorized access to this organization",
            },
          },
        },
        LoginRequest: {
          type: "object",
          required: ["email", "password"],
          properties: {
            email: {
              type: "string",
              format: "email",
              example: "admin@myfleet.com",
            },
            password: {
              type: "string",
              format: "password",
              example: "securepassword123",
            },
          },
        },
        LoginResponse: {
          type: "object",
          properties: {
            user: { $ref: "#/components/schemas/User" },
            message: {
              type: "string",
              example: "Login successful",
            },
          },
        },
        RegisterOrgRequest: {
          type: "object",
          required: ["name", "adminEmail"],
          properties: {
            name: {
              type: "string",
              example: "Acme Fleet Solutions",
            },
            adminEmail: {
              type: "string",
              format: "email",
              example: "admin@acmefleet.com",
            },
            password: {
              type: "string",
              format: "password",
              example: "securePassword123!",
            },
          },
        },
        RegisterOrgResponse: {
          type: "object",
          properties: {
            organization: { $ref: "#/components/schemas/Organization" },
            user: { $ref: "#/components/schemas/User" },
          },
        },
        Organization: {
          type: "object",
          properties: {
            id: { type: "string", example: "cm0123456789" },
            name: { type: "string", example: "Acme Fleet Solutions" },
            apiKey: { type: "string", nullable: true, example: "fv_live_9f8e7d6c5b4a..." },
            status: { type: "string", example: "ACTIVE" },
            createdAt: { type: "string", format: "date-time" },
            updatedAt: { type: "string", format: "date-time" },
            _count: {
              type: "object",
              properties: {
                users: { type: "integer", example: 5 },
                devices: { type: "integer", example: 12 },
                vehicles: { type: "integer", example: 10 },
              },
            },
          },
        },
        DetailedOrganization: {
          type: "object",
          properties: {
            id: { type: "string", example: "cm0123456789", description: "Unique CUID of the organization." },
            name: { type: "string", example: "Acme Fleet Solutions", description: "Registered corporate name." },
            status: {
              type: "string",
              enum: ["ACTIVE", "SUSPENDED", "CANCELLED"],
              example: "ACTIVE",
              description: "Current organizational operating status.",
            },
            subscriptionPlan: {
              type: "string",
              example: "TRIAL",
              description: "Active subscription plan (e.g. TRIAL, STANDARD, ENTERPRISE).",
            },
            subscriptionEndDate: {
              type: "string",
              format: "date-time",
              nullable: true,
              example: "2026-12-31T23:59:59.000Z",
              description: "Expiry timestamp of current subscription plan if applicable.",
            },
            stripeCustomerId: {
              type: "string",
              nullable: true,
              example: "cus_123456789",
              description: "Associated Stripe customer ID. Redacted for non-admin callers.",
            },
            apiKey: {
              type: "string",
              nullable: true,
              example: "fv_live_9f8e7d6c5b4a3a2b1c...",
              description: "Live organization API key for IoT/REST ingestion. Redacted for non-admin callers.",
            },
            createdAt: { type: "string", format: "date-time", example: "2026-01-01T00:00:00.000Z" },
            updatedAt: { type: "string", format: "date-time", example: "2026-01-02T00:00:00.000Z" },
            _count: {
              type: "object",
              description: "Aggregated resource statistics for this tenant.",
              properties: {
                users: { type: "integer", example: 5, description: "Total registered team members." },
                devices: { type: "integer", example: 12, description: "Total tracked hardware devices (IMEIs)." },
                vehicles: { type: "integer", example: 10, description: "Total vehicles configured in fleet." },
                geofences: { type: "integer", example: 3, description: "Total active polygon geofence zones." },
              },
            },
          },
        },
        OrganizationDetailsResponse: {
          type: "object",
          properties: {
            organization: { $ref: "#/components/schemas/DetailedOrganization" },
          },
        },
        User: {
          type: "object",
          properties: {
            id: { type: "string", example: "usr_9988776655" },
            email: { type: "string", example: "admin@acmefleet.com" },
            role: { type: "string", example: "ADMIN" },
            organizationId: { type: "string", example: "cm0123456789" },
            createdAt: { type: "string", format: "date-time" },
          },
        },
        RegisterVehicleRequest: {
          type: "object",
          required: ["plateNumber"],
          properties: {
            plateNumber: { type: "string", example: "ABC-1234" },
            make: { type: "string", example: "Toyota" },
            model: { type: "string", example: "Camry" },
            year: { type: "integer", example: 2023 },
            color: { type: "string", example: "Silver" },
            vin: { type: "string", example: "1HGCR2F83HA000000" },
            vehicleType: { type: "string", example: "SEDAN" },
            status: { type: "string", example: "ACTIVE" },
            fuelType: { type: "string", example: "PETROL" },
            maxFuelCapacity: { type: "number", example: 60.0 },
            orgId: { type: "string", example: "cm0123456789" },
          },
        },
        Vehicle: {
          type: "object",
          properties: {
            id: { type: "string", example: "veh_123456" },
            plateNumber: { type: "string", example: "ABC-1234" },
            make: { type: "string", nullable: true, example: "Toyota" },
            model: { type: "string", nullable: true, example: "Camry" },
            year: { type: "integer", nullable: true, example: 2023 },
            color: { type: "string", nullable: true, example: "Silver" },
            vin: { type: "string", nullable: true, example: "1HGCR2F83HA000000" },
            vehicleType: { type: "string", nullable: true, example: "SEDAN" },
            status: { type: "string", example: "ACTIVE" },
            fuelType: { type: "string", nullable: true, example: "PETROL" },
            maxFuelCapacity: { type: "number", nullable: true, example: 60.0 },
            bleFuelChannel: { type: "integer", nullable: true, example: 1 },
            organizationId: { type: "string", example: "cm0123456789" },
            createdAt: { type: "string", format: "date-time" },
            updatedAt: { type: "string", format: "date-time" },
            device: { $ref: "#/components/schemas/Device" },
          },
        },
        FuelCalibrationPoint: {
          type: "object",
          properties: {
            rawValue: { type: "integer", example: 620 },
            liters: { type: "number", example: 10.5 },
          },
        },
        FuelCalibrationTableResponse: {
          type: "object",
          properties: {
            vehicleId: { type: "string", example: "veh_123456" },
            points: {
              type: "array",
              items: { $ref: "#/components/schemas/FuelCalibrationPoint" },
            },
          },
        },
        UpdateFuelCalibrationTableRequest: {
          type: "object",
          required: ["points"],
          properties: {
            points: {
              type: "array",
              items: { $ref: "#/components/schemas/FuelCalibrationPoint" },
            },
          },
        },
        RegisterDeviceRequest: {
          type: "object",
          required: ["imei"],
          properties: {
            imei: { type: "string", example: "353456789012345" },
            orgId: { type: "string", example: "cm0123456789" },
          },
        },
        Device: {
          type: "object",
          properties: {
            id: { type: "string", example: "dev_987654" },
            imei: { type: "string", example: "353456789012345" },
            status: { type: "string", example: "ACTIVE" },
            organizationId: { type: "string", example: "cm0123456789" },
            vehicleId: { type: "string", nullable: true, example: "veh_123456" },
            createdAt: { type: "string", format: "date-time" },
            updatedAt: { type: "string", format: "date-time" },
            vehicle: { $ref: "#/components/schemas/Vehicle" },
          },
        },
        AssignDeviceRequest: {
          type: "object",
          properties: {
            vehicleId: {
              type: "string",
              nullable: true,
              example: "veh_123456",
              description: "Pass vehicle ID string to assign, or `null` to unassign.",
            },
          },
        },
        ApiKeyResponse: {
          type: "object",
          properties: {
            apiKey: {
              type: "string",
              nullable: true,
              example: "fv_live_a1b2c3d4e5f6...",
            },
          },
        },
        LiveLocation: {
          type: "object",
          properties: {
            deviceId: { type: "string", example: "dev_987654" },
            vehicleId: { type: "string", nullable: true, example: "veh_123456" },
            plateNumber: { type: "string", nullable: true, example: "ABC-1234" },
            latitude: { type: "number", example: 37.7749 },
            longitude: { type: "number", example: -122.4194 },
            speed: { type: "number", example: 45.5 },
            heading: { type: "number", example: 180 },
            ignition: { type: "boolean", example: true },
            batteryLevel: { type: "number", example: 12.8 },
            fuelLevelRaw: { type: "number", example: 45.2 },
            timestamp: { type: "string", format: "date-time" },
          },
        },
        TelemetryPoint: {
          type: "object",
          properties: {
            time: { type: "string", format: "date-time" },
            lat: { type: "number", example: 37.7749 },
            lng: { type: "number", example: -122.4194 },
            speed: { type: "number", example: 45.5 },
            ignition: { type: "boolean", example: true },
            fuelLevelRaw: { type: "number", example: 45.2 },
            odometer: { type: "number", example: 12050.2 },
          },
        },
        HistorySummary: {
          type: "object",
          properties: {
            totalDistanceKm: { type: "number", example: 120.5 },
            drivingDurationMinutes: { type: "integer", example: 150 },
            idleDurationMinutes: { type: "integer", example: 30 },
            stopDurationMinutes: { type: "integer", example: 15 },
            maxSpeedKmh: { type: "integer", example: 85 },
            avgSpeedKmh: { type: "number", example: 48.2 },
            startTime: { type: "string", format: "date-time" },
            endTime: { type: "string", format: "date-time" },
            startOdometer: { type: "number", nullable: true, example: 12050.2 },
            endOdometer: { type: "number", nullable: true, example: 12170.7 },
          },
        },
        UtilizationReportResponse: {
          type: "object",
          properties: {
            orgId: { type: "string" },
            period: {
              type: "object",
              properties: {
                start: { type: "string", format: "date-time" },
                end: { type: "string", format: "date-time" },
              }
            },
            groupBy: { type: "string" },
            fleetSummary: {
              type: "object",
              nullable: true,
              properties: {
                totalVehicles: { type: "number" },
                vehiclesWithData: { type: "number" },
                totalDistanceKm: { type: "number" },
                totalDrivingMinutes: { type: "number" },
                totalIdleMinutes: { type: "number" },
                totalStoppedMinutes: { type: "number" },
                avgUtilizationPercent: { type: "number" },
                avgDailyDistanceKm: { type: "number" },
                maxSpeedKmh: { type: "number" },
                avgSpeedKmh: { type: "number" },
                fuelConsumedLiters: { type: "number", nullable: true }
              }
            },
            vehicles: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  vehicleId: { type: "string" },
                  plateNumber: { type: "string" },
                  imei: { type: "string" },
                  make: { type: "string", nullable: true },
                  model: { type: "string", nullable: true },
                  summary: {
                    type: "object",
                    properties: {
                      totalDistanceKm: { type: "number" },
                      drivingMinutes: { type: "number" },
                      idleMinutes: { type: "number" },
                      stoppedMinutes: { type: "number" },
                      utilizationPercent: { type: "number" },
                      maxSpeedKmh: { type: "number" },
                      avgSpeedKmh: { type: "number" },
                      telemetryPoints: { type: "number" },
                      startOdometer: { type: "number", nullable: true },
                      endOdometer: { type: "number", nullable: true },
                      fuelStartLiters: { type: "number", nullable: true },
                      fuelEndLiters: { type: "number", nullable: true },
                      fuelConsumedLiters: { type: "number", nullable: true }
                    }
                  },
                  timeSeries: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        bucket: { type: "string", format: "date-time" },
                        distanceKm: { type: "number" },
                        drivingMinutes: { type: "number" },
                        idleMinutes: { type: "number" },
                        stoppedMinutes: { type: "number" },
                        maxSpeedKmh: { type: "number" },
                        avgSpeedKmh: { type: "number" },
                        telemetryPoints: { type: "number" }
                      }
                    }
                  }
                }
              }
            },
            metadata: {
              type: "object",
              properties: {
                queryTimeMs: { type: "number" },
                vehiclesQueried: { type: "number" },
                vehiclesWithData: { type: "number" },
                totalTelemetryPoints: { type: "number" }
              }
            }
          }
        },
        FuelAnalyticsResponse: {
          type: "object",
          properties: {
            orgId: { type: "string" },
            period: {
              type: "object",
              properties: {
                start: { type: "string", format: "date-time" },
                end: { type: "string", format: "date-time" },
              }
            },
            groupBy: { type: "string" },
            fleetFuelSummary: { $ref: "#/components/schemas/FleetFuelSummary" },
            vehicles: {
              type: "array",
              items: { $ref: "#/components/schemas/VehicleFuelResult" }
            },
            metadata: {
              type: "object",
              properties: {
                queryTimeMs: { type: "number" },
                vehiclesQueried: { type: "number" },
                vehiclesWithFuelData: { type: "number" },
                totalTelemetryPoints: { type: "number" },
                thresholds: { type: "object" }
              }
            }
          }
        },
        FleetFuelSummary: {
          type: "object",
          properties: {
            totalVehicles: { type: "number" },
            vehiclesWithFuelData: { type: "number" },
            vehiclesWithoutFuelData: { type: "number" },
            totalFuelConsumedLiters: { type: "number" },
            avgFuelConsumedPerVehicleLiters: { type: "number" },
            fleetFuelEfficiencyKmPerL: { type: "number" },
            fleetFuelEfficiencyL100Km: { type: "number" },
            totalDistanceKm: { type: "number" },
            fleetAvgCurrentFuelLiters: { type: "number" },
            fleetAvgCurrentFuelPercent: { type: "number" },
            lowFuelVehicleCount: { type: "number" },
            criticalFuelVehicleCount: { type: "number" },
            totalRefuelEvents: { type: "number" },
            totalDrainEvents: { type: "number" },
            totalTheftSuspectedEvents: { type: "number" },
            fuelDistribution: { $ref: "#/components/schemas/FuelDistribution" }
          }
        },
        FuelDistribution: {
          type: "object",
          properties: {
            critical_0_20: { type: "number" },
            low_20_40: { type: "number" },
            medium_40_60: { type: "number" },
            good_60_80: { type: "number" },
            full_80_100: { type: "number" }
          }
        },
        VehicleFuelResult: {
          type: "object",
          properties: {
            vehicleId: { type: "string" },
            plateNumber: { type: "string" },
            imei: { type: "string" },
            make: { type: "string", nullable: true },
            model: { type: "string", nullable: true },
            fuelType: { type: "string", nullable: true },
            maxFuelCapacity: { type: "number", nullable: true },
            summary: { $ref: "#/components/schemas/VehicleFuelSummary" },
            fuelTimeSeries: {
              type: "array",
              items: { $ref: "#/components/schemas/FuelTimeBucket" }
            },
            events: {
              type: "array",
              items: { $ref: "#/components/schemas/DetectedFuelEvent" }
            }
          }
        },
        VehicleFuelSummary: {
          type: "object",
          properties: {
            fuelConsumedLiters: { type: "number", nullable: true },
            fuelEfficiencyKmPerL: { type: "number", nullable: true },
            fuelEfficiencyL100Km: { type: "number", nullable: true },
            totalDistanceKm: { type: "number" },
            fuelStartLiters: { type: "number", nullable: true },
            fuelEndLiters: { type: "number", nullable: true },
            currentFuelPercent: { type: "number", nullable: true },
            avgFuelLevelLiters: { type: "number", nullable: true },
            minFuelLevelLiters: { type: "number", nullable: true },
            maxFuelLevelLiters: { type: "number", nullable: true },
            avgDailyConsumptionLiters: { type: "number", nullable: true },
            estimatedRangeKm: { type: "number", nullable: true },
            refuelEvents: { type: "number" },
            drainEvents: { type: "number" },
            theftSuspectedEvents: { type: "number" },
            telemetryPoints: { type: "number" }
          }
        },
        FuelTimeBucket: {
          type: "object",
          properties: {
            bucket: { type: "string", format: "date-time" },
            avgFuelLiters: { type: "number" },
            minFuelLiters: { type: "number" },
            maxFuelLiters: { type: "number" },
            fuelConsumedLiters: { type: "number" },
            distanceKm: { type: "number" },
            efficiencyKmPerL: { type: "number" },
            telemetryPoints: { type: "number" }
          }
        },
        DetectedFuelEvent: {
          type: "object",
          properties: {
            eventType: { type: "string", enum: ["REFUEL", "DRAIN", "THEFT_SUSPECTED"] },
            startTime: { type: "string", format: "date-time" },
            endTime: { type: "string", format: "date-time" },
            fuelBefore: { type: "number" },
            fuelAfter: { type: "number" },
            deltaLiters: { type: "number" },
            latitude: { type: "number", nullable: true },
            longitude: { type: "number", nullable: true },
            ignitionDuring: { type: "boolean" }
          }
        },
        HistoryResponse: {
          type: "object",
          properties: {
            imei: { type: "string", example: "353456789012345" },
            orgId: { type: "string", example: "cm0123456789" },
            summary: { $ref: "#/components/schemas/HistorySummary" },
            route: {
              type: "array",
              items: { $ref: "#/components/schemas/TelemetryPoint" },
            },
            metadata: {
              type: "object",
              properties: {
                totalTelemetryPoints: { type: "integer", example: 50000 },
                returnedRoutePoints: { type: "integer", example: 1200 },
                simplified: { type: "boolean", example: true },
                queryTimeMs: { type: "integer", example: 450 },
              },
            },
          },
        },
        Geofence: {
          type: "object",
          properties: {
            id: { type: "string" },
            name: { type: "string" },
            description: { type: "string", nullable: true },
            type: { type: "string", enum: ["POLYGON", "CIRCLE"] },
            color: { type: "string" },
            isActive: { type: "boolean" },
            alertOnEnter: { type: "boolean" },
            alertOnExit: { type: "boolean" },
            speedLimitKmh: { type: "number", nullable: true },
            createdAt: { type: "string", format: "date-time" },
            updatedAt: { type: "string", format: "date-time" },
            centerLat: { type: "number", nullable: true },
            centerLng: { type: "number", nullable: true },
            radiusMeters: { type: "number", nullable: true },
            coordinates: { type: "array", items: { type: "array", items: { type: "number" } }, nullable: true }
          }
        },
        GeofenceListResponse: {
          type: "object",
          properties: {
            geofences: { type: "array", items: { $ref: "#/components/schemas/Geofence" } },
            totalCount: { type: "integer" }
          }
        },
        CreateGeofenceRequest: {
          type: "object",
          required: ["name", "type"],
          properties: {
            name: { type: "string" },
            description: { type: "string" },
            type: { type: "string", enum: ["POLYGON", "CIRCLE"] },
            color: { type: "string" },
            alertOnEnter: { type: "boolean" },
            alertOnExit: { type: "boolean" },
            speedLimitKmh: { type: "number" },
            coordinates: { type: "array", items: { type: "array", items: { type: "number" } } },
            center: { type: "object", properties: { lat: { type: "number" }, lng: { type: "number" } } },
            radiusMeters: { type: "number" }
          }
        },
        UpdateGeofenceRequest: {
          type: "object",
          properties: {
            name: { type: "string" },
            description: { type: "string" },
            color: { type: "string" },
            isActive: { type: "boolean" },
            alertOnEnter: { type: "boolean" },
            alertOnExit: { type: "boolean" },
            speedLimitKmh: { type: "number" }
          }
        },
        GeofenceAlert: {
          type: "object",
          properties: {
            id: { type: "string" },
            geofenceId: { type: "string" },
            organizationId: { type: "string" },
            imei: { type: "string" },
            eventType: { type: "string", enum: ["ENTER", "EXIT", "SPEED_VIOLATION"] },
            latitude: { type: "number" },
            longitude: { type: "number" },
            speed: { type: "number", nullable: true },
            timestamp: { type: "string", format: "date-time" },
            createdAt: { type: "string", format: "date-time" },
            geofence: { type: "object", properties: { name: { type: "string" }, type: { type: "string" } } }
          }
        },
        GeofenceAlertListResponse: {
          type: "object",
          properties: {
            alerts: { type: "array", items: { $ref: "#/components/schemas/GeofenceAlert" } },
            totalCount: { type: "integer" }
          }
        }
      },
    },
  };

  return NextResponse.json(openApiSpec);
}
